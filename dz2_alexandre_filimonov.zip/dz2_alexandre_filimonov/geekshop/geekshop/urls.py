"""geekshop URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
import mainapp.views as mainapp

urlpatterns = [
    path('', mainapp.main, name='index'),
    path('products/', mainapp.products, name='products'),
    path('contacts/', mainapp.contacts, name='contacts'),
    path('item1/', mainapp.item1, name='item1'),
    path('item2/', mainapp.item2, name='item2'),
    path('item3/', mainapp.item3, name='item3'),
    path('item4/', mainapp.item4, name='item4'),
    path('item5/', mainapp.item5, name='item5'),
    path('admin/', admin.site.urls),
]
