from django.shortcuts import render

# Create your views here.
def main(request):
    context = { 
        'title': 'главная', 	
    }
    return render(request, 'mainapp/index.html', context) 

def products(request):
    context = { 
        'title': 'каталог букетов', 	
    }
    return render(request, 'mainapp/products.html', context) 

def contacts(request):
    contacts = [
		{ 
			'city': 'Москва', 	
			'phone': '+7(905)456-67-67', 	
			'email': 'magaizinzvetov@magaizinzvetov.ru', 	
			'address': '119034 г.Москва, ул.Остоженка, д.12/1', 			
		}, 
		{ 
			'city': 'Санкт-Петербург', 	
			'phone': '+7(812)956-67-67', 	
			'email': 'magaizinzvetov_spb@magaizinzvetov.ru', 	
			'address': '118034 г.Санкт-Петербург, ул.Плеханова, д.15', 			
		}		
	]
    context = { 
        'title': 'контакты', 
        'contacts': contacts, 		
    }
    return render(request, 'mainapp/contacts.html', context) 
	
def item1(request):
    context = { 
        'title': 'букет "Подарочный"'.title(), #one of the ways to make first latter of the title as Capital; another way is - | in template 	
    }
    return render(request, 'mainapp/item1.html', context) 

def item2(request):
    context = { 
        'title': 'букет "С днем рожденья!"', 	
    }
    return render(request, 'mainapp/item2.html', context) 

def item3(request):
    context = { 
        'title': 'букет "Сюрприз!"', 	
    }
    return render(request, 'mainapp/item3.html', context) 

def item4(request):
    context = { 
        'title': 'букет "Свадебный-1"', 	
    }
    return render(request, 'mainapp/item4.html', context) 

def item5(request):
    context = { 
        'title': 'букет "Свадебный-2"', 	
    }
    return render(request, 'mainapp/item5.html', context) 

